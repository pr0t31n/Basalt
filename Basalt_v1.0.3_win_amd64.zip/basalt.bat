@echo off
setlocal
set "BASALT_DIR=%~dp0"
"%BASALT_DIR%python\python.exe" "%BASALT_DIR%basalt.py" %*
endlocal
